CLAUDE CODE TRAINING - DAY 1
Fundamentals - the agentic loop, memory, context, permissions
Mastronardi Produce  |  Delivered by Scott Hay, Helios-Core
Updated August 2026

LABS
  - Day0_Lab_0_Environment_Gate.pdf
  - Day1_Lab_A_The_Agentic_Build_Loop.pdf
  - Day1_Lab_B_Teaching_Claude_Your_Codebase.pdf
  - Day1_Lab_C_Precision_Recovery.pdf
  - Day1_Lab_D_Ship_It.pdf

HANDOUTS
  - Claude_Code_CLAUDE_md_Templates.pdf
  - Claude_Code_Prompt_Packet.pdf
  - Claude_Code_Quick_Reference.pdf
  - Claude_Code_Stack.pdf
  - Claude_Code_Workflow_Playbook.pdf

Work the labs in order. Handouts are reference - keep the Quick Reference open.
Slides are not included; your instructor presents them live.
