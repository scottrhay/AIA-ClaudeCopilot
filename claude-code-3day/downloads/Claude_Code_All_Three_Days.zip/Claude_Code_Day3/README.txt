CLAUDE CODE TRAINING - DAY 3
Production - MCP, subagents, agent teams, CI/CD
Mastronardi Produce  |  Delivered by Scott Hay, Helios-Core
Updated August 2026

LABS
  - Day3_Lab_A_MCP.pdf
  - Day3_Lab_B_Subagents_And_Teams.pdf
  - Day3_Lab_C_CICD.pdf
  - Day3_Lab_D_Capstone.pdf

HANDOUTS
  - Claude_Code_Quick_Reference.pdf
  - Subagents_And_Teams_Guide.pdf

Work the labs in order. Handouts are reference - keep the Quick Reference open.
Slides are not included; your instructor presents them live.
