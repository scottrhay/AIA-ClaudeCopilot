CLAUDE CODE TRAINING - DAY 2
Extensions - skills, hooks, invocation control, plugins
Mastronardi Produce  |  Delivered by Scott Hay, Helios-Core
Updated August 2026

LABS
  - Day2_Lab_A_Build_Your_First_Skill.pdf
  - Day2_Lab_B_Hooks_And_Commands.pdf
  - Day2_Lab_C_Advanced_Skill_Workflows.pdf
  - Day2_Lab_D_Package_And_Ship.pdf

HANDOUTS
  - Claude_Code_Quick_Reference.pdf
  - Claude_Code_Skills_Reference.pdf
  - Hooks_Events_Reference.pdf

Work the labs in order. Handouts are reference - keep the Quick Reference open.
Slides are not included; your instructor presents them live.
