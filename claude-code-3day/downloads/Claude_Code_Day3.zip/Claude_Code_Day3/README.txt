Claude Code Day 3

Includes Labs 3A-3D, handouts, and all three Slide 60 / Lab 3C starter files under Starter-Files/Day3_Lab_C/.

Slide 60: in VS Code PowerShell, run:
& "$env:ProgramFiles\Git\bin\bash.exe" ./scripts/ci-review.sh
Write-Host "exit code: $LASTEXITCODE"

Do not ask an active Claude Code session to run the script because it launches claude -p. Do not use --bare or paste an API key.
