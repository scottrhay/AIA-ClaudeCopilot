CLAUDE CODE TRAINING - DAY 3
Production - MCP, agents, authenticated print mode, and Azure-ready CI/CD
Mastronardi Produce  |  Delivered by Scott Hay, AIA Copilot
Updated August 26, 2026

LABS
  - Day3_Lab_A_MCP.pdf
  - Day3_Lab_B_Subagents_And_Teams.pdf
  - Day3_Lab_C_CICD.pdf
  - Day3_Lab_D_Capstone.pdf

HANDOUTS
  - Claude_Code_Quick_Reference.pdf
  - Subagents_And_Teams_Guide.pdf

Work the labs in order. Use the existing Claude Code workstation login for Lab 3C. Do not use --bare or paste an API key.
Slides are not included; your instructor presents them live.
