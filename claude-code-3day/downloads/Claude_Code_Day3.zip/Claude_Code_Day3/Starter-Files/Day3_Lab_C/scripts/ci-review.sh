#!/bin/bash
set -e

MAX_TURNS=10
MODEL="${CI_REVIEW_MODEL:-sonnet}"
export CLAUDE_CODE_MAX_OUTPUT_TOKENS="${CLAUDE_CODE_MAX_OUTPUT_TOKENS:-4096}"
REVIEW_SCOPE="${REVIEW_SCOPE:-the code in src/}"
SCHEMA='{"type":"object","properties":{"issues":{"type":"array"},"score":{"type":"number"}},"required":["issues","score"]}'

# This local lab script uses the existing authenticated Claude Code login.
# It deliberately does not use --bare or require an API key.

# Replay the stored verdict without another Claude call.
SHA=$(git rev-parse HEAD)
MARKER=".ci-review/${SHA}.done"
if [ -f "$MARKER" ]; then
  STORED_EXIT=$(cat "$MARKER")
  echo "SKIP: HEAD ${SHA:0:7} already reviewed - reusing verdict $STORED_EXIT."
  exit "$STORED_EXIT"
fi

set +e
claude -p "Review $REVIEW_SCOPE for security and quality issues." \
  --strict-mcp-config \
  --disable-slash-commands \
  --setting-sources user \
  --model "$MODEL" \
  --tools "Read,Grep,Glob" \
  --allowedTools "Read,Grep,Glob" \
  --permission-mode dontAsk \
  --max-turns "$MAX_TURNS" \
  --json-schema "$SCHEMA" \
  --output-format json > review.json
CLAUDE_EXIT=$?
set -e

# Inspect the envelope before parsing success output. Node is already a
# course prerequisite, so the demo does not depend on a separate jq install.
SUBTYPE=$(node -e 'try { const j=require("./review.json"); process.stdout.write(j.subtype || ""); } catch {}' || true)
TURNS=$(node -e 'try { const j=require("./review.json"); process.stdout.write(String(j.num_turns || 0)); } catch { process.stdout.write("0"); }' || true)
case "$SUBTYPE" in
  error_max_turns|error_during_execution|error_max_structured_output_retries)
    echo "BOUND OR CLAUDE ERROR ($SUBTYPE; ${TURNS}/${MAX_TURNS} turns) - failing safe."
    exit 2
    ;;
esac
if [ "$CLAUDE_EXIT" -ne 0 ]; then
  echo "CLAUDE EXIT $CLAUDE_EXIT - failing safe."
  exit 2
fi

# Never mark an incomplete envelope reviewed.
if ! node -e 'try { const j=require("./review.json"); process.exit(j.structured_output && typeof j.structured_output.score === "number" ? 0 : 1); } catch { process.exit(1); }'; then
  echo "INVALID OR INCOMPLETE REVIEW ENVELOPE - failing safe."
  exit 2
fi

SCORE=$(node -e 'const j=require("./review.json"); process.stdout.write(String(j.structured_output.score));')
echo "Review score: $SCORE"
VERDICT_EXIT=0
if awk -v s="$SCORE" 'BEGIN { exit !(s+0 < 6) }'; then
  echo "ADVISORY FINDING (score < 6)"
  VERDICT_EXIT=1
else
  echo "REVIEW PASSED"
fi

mkdir -p .ci-review
echo "$VERDICT_EXIT" > "$MARKER"
exit "$VERDICT_EXIT"
