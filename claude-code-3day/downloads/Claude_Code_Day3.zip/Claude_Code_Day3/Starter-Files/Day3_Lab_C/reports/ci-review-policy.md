# CI Review Policy

## Review criteria
- Security: injection, secrets, unsafe execution, and missing authorization checks
- Validation: external input is validated before use
- Reliability: errors are handled and failures are observable
- Testing: changed behavior has targeted tests
- Maintainability: findings cite a file and explain the smallest safe correction

## Severity
- CRITICAL: credible exploit, secret exposure, or destructive production risk
- HIGH: likely security or reliability failure requiring correction before release
- MEDIUM: material defect or missing test that needs triage
- LOW: improvement that should not block delivery

## Rollout
The first release is advisory. Findings inform a human reviewer and do not merge, block, or modify code.
